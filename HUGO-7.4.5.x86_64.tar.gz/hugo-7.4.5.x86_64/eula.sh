#!/bin/bash
SCRIPTPATH=$(readlink -f "$0")
SCRIPTDIR=`dirname "$SCRIPTPATH"`

read -p "Read the end user license agreement. [enter]: "

cat "$SCRIPTDIR"/HUGO_EULA.txt | more -d

read -p "Do you accept the EULA? [y/n]: " input

if [ "$input" != "y" ]; then
	echo "You must accept the EULA to install this program."
	exit 1
fi
